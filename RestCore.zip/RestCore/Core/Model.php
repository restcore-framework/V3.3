<?php namespace Core;

use \Illuminate\Database\Eloquent\Model as Eloquent;

abstract class Model extends Eloquent
{
    // Model
}