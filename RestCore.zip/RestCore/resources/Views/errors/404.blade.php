@extends('app')

@section('content')
    <h1>Page Not Found => 404</h1>
@endsection