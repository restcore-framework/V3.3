

<?php $__env->startSection('title'); ?>
    index page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="main">
    <h1>index page</h1>
    </div>























<!--    --><?php
//    use App\Services\Script;
//    Script::JSerror()
//    ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/RestCore/resources/Views/index.blade.php ENDPATH**/ ?>