

<?php $__env->startSection('content'); ?>
<h1>Server Error => 500</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/RestCore/resources/Views/errors/500.blade.php ENDPATH**/ ?>