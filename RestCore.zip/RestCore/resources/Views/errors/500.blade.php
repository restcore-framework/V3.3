@extends('app')

@section('content')
<h1>Server Error => 500</h1>
@endsection
