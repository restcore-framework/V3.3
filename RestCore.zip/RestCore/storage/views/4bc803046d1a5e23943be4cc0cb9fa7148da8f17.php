
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <style>
        .main{
            text-align: center;
        }
        h1{
            text-align: center;
        }
    </style>
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/RestCore/resources/Views/app.blade.php ENDPATH**/ ?>