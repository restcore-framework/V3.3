@extends('app')

@section('title')
    index page
@endsection

@section('content')

    <div class="main">
    <h1>index page</h1>
    </div>























<!--    --><?php
//    use App\Services\Script;
//    Script::JSerror()
//    ?>

@endsection
